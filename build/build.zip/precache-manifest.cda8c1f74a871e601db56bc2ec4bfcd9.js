self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d5c2795a2ca22705d031ecd71a0bb338",
    "url": "/index.html"
  },
  {
    "revision": "73c218e90df01fb5e29f",
    "url": "/static/css/main.29050688.chunk.css"
  },
  {
    "revision": "756627ebd87287e3c315",
    "url": "/static/js/2.5e1eaf2d.chunk.js"
  },
  {
    "revision": "73c218e90df01fb5e29f",
    "url": "/static/js/main.7e516843.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "83679ceae0f7bb957eef2f3bdfe113d4",
    "url": "/static/media/Alann.83679cea.jpg"
  },
  {
    "revision": "bbb9e7de90cf0a1922dd7e590ad495e6",
    "url": "/static/media/HAY.bbb9e7de.png"
  },
  {
    "revision": "16f332f683cd4e5b70cec85e5c24ab0c",
    "url": "/static/media/Jamil.16f332f6.png"
  },
  {
    "revision": "eca9fbcc7371d1902ec45745d296d89b",
    "url": "/static/media/Karim_Chaari.eca9fbcc.jpg"
  },
  {
    "revision": "4f938fa2a6c86e315aab57a86040600b",
    "url": "/static/media/Lightency_dark_opt.4f938fa2.svg"
  },
  {
    "revision": "fbc6bacb623cbe975cdc7e9ed5795b6e",
    "url": "/static/media/Mauritius1.fbc6bacb.jpg"
  },
  {
    "revision": "400a12896b278d9a01f95833328ee91e",
    "url": "/static/media/accessibleenergy.400a1289.png"
  },
  {
    "revision": "5d606419aea62114ae1efaa4acaccfec",
    "url": "/static/media/adaptability.5d606419.png"
  },
  {
    "revision": "7944c7ae483f029f8bc21b9b0d4cc68c",
    "url": "/static/media/africa_blog1.7944c7ae.jpg"
  },
  {
    "revision": "32131570539b5999ba2f1411d1a879ea",
    "url": "/static/media/africa_opt_animated.32131570.svg"
  },
  {
    "revision": "6a5ef385d9e73b663e0ec20045412286",
    "url": "/static/media/analmine.6a5ef385.png"
  },
  {
    "revision": "7406e544c3789309d64d081620a869ad",
    "url": "/static/media/asma.7406e544.png"
  },
  {
    "revision": "35757f96b6750771f04de11e9b7374ae",
    "url": "/static/media/aura.35757f96.png"
  },
  {
    "revision": "90830989c26addfe54b10fbdb92fd901",
    "url": "/static/media/availability.90830989.png"
  },
  {
    "revision": "7d8c2f084a58311d4c6c70e5923e8934",
    "url": "/static/media/benji.7d8c2f08.png"
  },
  {
    "revision": "1e5f3242f36a41095359de0e7ff48122",
    "url": "/static/media/blockchain.1e5f3242.jpg"
  },
  {
    "revision": "c1f09f19703c59332a60f89495cf7517",
    "url": "/static/media/boubaker.c1f09f19.png"
  },
  {
    "revision": "9082b0f5b70aafa1b8aa929859b05b9f",
    "url": "/static/media/chamous.9082b0f5.jpg"
  },
  {
    "revision": "2da26aa41f2a768b9e5c8053e8e0ddd4",
    "url": "/static/media/costsaving.2da26aa4.png"
  },
  {
    "revision": "ac8f6a468646e9e7488496c258ecc7b2",
    "url": "/static/media/decentralization.ac8f6a46.png"
  },
  {
    "revision": "fc161200a8fcea05b35cbaa7edb946a0",
    "url": "/static/media/energy.fc161200.jpg"
  },
  {
    "revision": "ae0f0dbeb47b5e54f667ae3d8cca9855",
    "url": "/static/media/environment.ae0f0dbe.jpg"
  },
  {
    "revision": "8f5ce27564945d2c9a10ef827549a78c",
    "url": "/static/media/facebook.8f5ce275.png"
  },
  {
    "revision": "78f895f182c59c0690593a1116e38bdc",
    "url": "/static/media/ffers.78f895f1.jpeg"
  },
  {
    "revision": "1aa923801e5698c4687a14a1da6f432f",
    "url": "/static/media/greenenergy.1aa92380.png"
  },
  {
    "revision": "12bba864827314bd2e8f1bf756d40431",
    "url": "/static/media/iyed.12bba864.jpg"
  },
  {
    "revision": "4d14cc31886505dd4e276139142bf623",
    "url": "/static/media/job.4d14cc31.jpg"
  },
  {
    "revision": "c06295b591291ec186e380c92b3d3885",
    "url": "/static/media/lackofelectricity.c06295b5.png"
  },
  {
    "revision": "4b0c783048c883fa01e7d32d70de72cb",
    "url": "/static/media/life.4b0c7830.jpg"
  },
  {
    "revision": "fd0d5546fdbdc85c76c4372a0d51f1bc",
    "url": "/static/media/linkedin.fd0d5546.png"
  },
  {
    "revision": "cac624deb414035f0e1b0ac01484a8b8",
    "url": "/static/media/mailbox.cac624de.png"
  },
  {
    "revision": "c1fa1b7ee125b279d6a51135f9ab6a35",
    "url": "/static/media/mens.c1fa1b7e.jpg"
  },
  {
    "revision": "84f24a7c85238eb4bdccc6f9c6f85f54",
    "url": "/static/media/mine2.84f24a7c.jpg"
  },
  {
    "revision": "18b4f7f669bf840cd780b9aa7bdb7a1e",
    "url": "/static/media/mockapp.18b4f7f6.png"
  },
  {
    "revision": "b6b89d7a7a84af5b813ea45b94ca7588",
    "url": "/static/media/mohamed.b6b89d7a.png"
  },
  {
    "revision": "13b597d249eba8390ef299808f375653",
    "url": "/static/media/mohammed.13b597d2.png"
  },
  {
    "revision": "d58e2d33928300edb1db1da98fa0793b",
    "url": "/static/media/p13.d58e2d33.png"
  },
  {
    "revision": "f564f224b735bfdc42030cdfe011eab2",
    "url": "/static/media/p14.f564f224.png"
  },
  {
    "revision": "28fca9a80ff96122740a2933a8e81efb",
    "url": "/static/media/p15.28fca9a8.png"
  },
  {
    "revision": "4dc7287127768f31fe8d458075980961",
    "url": "/static/media/p16.4dc72871.png"
  },
  {
    "revision": "fdbeabf69dfc643aa2b27cb43c9e4835",
    "url": "/static/media/p6.fdbeabf6.png"
  },
  {
    "revision": "3107455fddc1801c0645cb135d592f8e",
    "url": "/static/media/parti.3107455f.jpg"
  },
  {
    "revision": "b5640c4c6d10f4d90264bf18da5941ad",
    "url": "/static/media/particules.b5640c4c.jpg"
  },
  {
    "revision": "1de19f4e1265726e90820365aef65911",
    "url": "/static/media/paymentissues.1de19f4e.png"
  },
  {
    "revision": "802cab0d89f07ffcea4ce8a394507651",
    "url": "/static/media/philippe.802cab0d.png"
  },
  {
    "revision": "825864fa1c4287663a346e54faf31542",
    "url": "/static/media/planet.825864fa.jpg"
  },
  {
    "revision": "6d6a9bd128edb1be71395265d5040428",
    "url": "/static/media/scalability.6d6a9bd1.png"
  },
  {
    "revision": "100a98b01cc1c5742fb21c112ed06f79",
    "url": "/static/media/school.100a98b0.jpg"
  },
  {
    "revision": "37a44cb8aac7db1a9e8690b822f3ef34",
    "url": "/static/media/test_450.37a44cb8.jpg"
  },
  {
    "revision": "99b0eeee7c1e824563a9f37f23c4e4c5",
    "url": "/static/media/thibault.99b0eeee.png"
  },
  {
    "revision": "ac32f19710fe97c1edd5d7027972c4e0",
    "url": "/static/media/transparency.ac32f197.png"
  },
  {
    "revision": "0251d8ee95aa6d1f3400faa3b46b4bcf",
    "url": "/static/media/twitter.0251d8ee.png"
  },
  {
    "revision": "c57458f0f3374228c95e1b9dc66b5904",
    "url": "/static/media/userfriendly.c57458f0.png"
  },
  {
    "revision": "2d29871bc6de6756dc45c3def7fb9631",
    "url": "/static/media/victoria.2d29871b.png"
  },
  {
    "revision": "800760d127964d9faa2389ab9d40906e",
    "url": "/static/media/wejden.800760d1.png"
  },
  {
    "revision": "18b2ca7ca5a187792fb34cc2a6942c5b",
    "url": "/static/media/why2.18b2ca7c.jpg"
  },
  {
    "revision": "65ccb5fe438ff90f0d9a9c13f97dbf6b",
    "url": "/static/media/yasmine.65ccb5fe.png"
  },
  {
    "revision": "680b7da9b92b476b3c9762ab9b1be804",
    "url": "/static/media/zoghlami.680b7da9.jpg"
  }
]);